package com.binary.tree;

public class Pair {
	public TreeNode treeNode;
	int level;
	
	public Pair(TreeNode treeNode, int level) {
		this.treeNode=treeNode;
		this.level=level;
	}
	
}
