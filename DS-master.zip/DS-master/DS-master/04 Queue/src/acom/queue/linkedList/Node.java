package acom.queue.linkedList;

public class Node {
	public int data;
	public Node next;
	
	public Node(int value) {
		data = value;
		next=null;
	}
}
