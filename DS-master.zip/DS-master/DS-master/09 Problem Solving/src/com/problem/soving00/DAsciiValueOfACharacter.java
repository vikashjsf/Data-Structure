//Find ASCII value of a character
package com.problem.soving00;

public class DAsciiValueOfACharacter {
	public static void main(String[] args) {
		char ch = 'A';
		asciiVlaueOfCharacter(ch);
	}
	
	public static void asciiVlaueOfCharacter(char ch) {
		int as = (int)ch;
		System.out.println("Ascii Value : "+as);
	}
}
