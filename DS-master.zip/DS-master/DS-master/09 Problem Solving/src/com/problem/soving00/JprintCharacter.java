package com.problem.soving00;

public class JprintCharacter {
	public static void main(String[] args) {
		char ch ;
		for (ch = 'A'; ch <='Z'; ch++) {
			System.out.println(ch + " "+ (int)ch);
		}
	}
}
