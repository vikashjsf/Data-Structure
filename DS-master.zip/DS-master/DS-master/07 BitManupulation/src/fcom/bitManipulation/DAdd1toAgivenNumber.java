//Add one to a given number.
package fcom.bitManipulation;

public class DAdd1toAgivenNumber {
	public static void main(String[] args) {
		int x = 4;
		int result = -~x;
		System.out.println("Result : "+result);
	}
}
