package ccom.bitwiseoperation;

public class EleftShift3 {
	public static void main(String[] args) {
		int x=1;
		for (int i = 0; i < 5 ; i++) {
			x <<= i;
			//x=x<<i;
			System.out.println(x);
		}
	}
}
