package com.xor;

public class A {
	public static void main(String[] args) {
		int x = 10;
		int y=10;
		System.out.println(x^y);
	}
}
